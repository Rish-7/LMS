#### Desktop

  * Gitbash
  * Cygwin w/ Curl, Netstat
  * MySQL Server
  * MySQL Workbench
  * Java JDK
  * Maven
  * Tomcat
  * Angular w/ dependencies: node, npm
  * Chrome w/ Augury 4.4.4+ installed
  * VS Code

#### AWS - EC2

  * None

#### AWS - RDS

  * Database per team member
  * Database per team

#### Jenkins

  * 3 Jobs per team - Unit, Integration and Staging

#### Git

  * A skeletal repository which the trainee teams can clone, build and deploy to get a basic e2e application

#### GITHUB Project Board

  * Epics, User Stories and Tasks for Sprint #1. Boards setup.