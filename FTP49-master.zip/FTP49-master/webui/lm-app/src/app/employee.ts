export class Employee {
    empId: number;
    empName: String;
    empEmail: String;
    empPhone: number;
    empDoj: Date;
    empDept:String;
    empLeaveBal:number;
    empMngrId:number;
    constructor(id: number,name:String,email:String,phone:number,doj:Date,dept:String,leavebal:number,mngrid:number) {
      this.empId = id;
      this.empName = name;
      this.empEmail = email;
      this.empPhone = phone;
      this.empDoj = doj;
      this.empDept = dept;
      this.empLeaveBal = leavebal;
      this.empMngrId = mngrid;
    }
}

