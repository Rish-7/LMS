import { Component, OnInit } from '@angular/core';
import { EmployeeService } from './employee.service';
import { Employee } from './employee';
import { Router } from '@angular/router';

@Component({
selector: 'app-root',
templateUrl: './employee.component.html',
styleUrls: ['./app.component.css'],
providers: [ EmployeeService ]
})

export class EmployeeComponent implements OnInit {
constructor(private employeeService: EmployeeService, private router:Router) { }
title = 'Leave Management Application';
employees: Employee[];

getEmployees(): void {
this.employeeService.getEmployees().then(employees => {
console.log('getEmployees promise resolved : ' + employees.length);
this.employees = employees;
}
);
}

login(empId): void{
localStorage.setItem("empId",empId);
this.router.navigateByUrl("/login");
}

ngOnInit(): void {
this.getEmployees();
}
}