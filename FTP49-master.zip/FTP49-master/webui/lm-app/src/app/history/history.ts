export class History {
    empId: number;
    leaveId: number;
    leaveAppliedOn: Date;
    leaveDaysLeft: number;
    leaveStartDate: Date;
    leaveEndDate:Date;
    leaveType:String;
    leaveReason:String;
    leaveStatus:String;
    leaveManagerComments:String;


    constructor(eid: number,lid:number,lAppliedOn:Date,lDaysLeft:number,lStartDate:Date,lEndDate:Date,
            lType:String,lReason:String,lStatus:String,lmngrCmnts:String) {
        this.empId = eid;
        this.leaveId = lid;
        this.leaveAppliedOn = lAppliedOn;
        this.leaveDaysLeft = lDaysLeft;
        this.leaveStartDate = lStartDate;
        this.leaveEndDate = lEndDate;
        this.leaveType = lType;
        this.leaveReason = lReason;
        this.leaveStatus = lStatus;
        this.leaveManagerComments = lmngrCmnts;
    }
}


