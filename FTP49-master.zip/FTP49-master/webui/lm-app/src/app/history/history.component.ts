import { Component, OnInit } from '@angular/core';
import { HistoryService } from  './history.service';
import { History } from './history';
import { Router } from '@angular/router';


@Component({
  selector: 'app-history',
  templateUrl: './history.component.html',
  styleUrls: ['./history.component.css']

})
export class HistoryComponent implements OnInit {

  constructor(private serf:HistoryService,private router:Router) { }
  userData:History[];

  ngOnInit() {
    this.serf.getDetails()
    .subscribe((data)=>this.userData=data);
    console.log(this.userData);
  }

  apply(empId): void{
    this.router.navigateByUrl("/apply");
  }
 

}
