import { Injectable } from '@angular/core';
import { History } from './history';
import { Http,Response } from '@angular/http';
import 'rxjs/add/operator/map';
import { Observable } from 'rxjs';


@Injectable()

export class HistoryService {
    
      constructor(private _http:Http) { }
      empId=localStorage.getItem('empId');
      getDetails():Observable<History[]> { 
       
          return this._http.get("http://localhost:8080/FTP49-0.0.1-SNAPSHOT/api/leavedetailsrest/data/" + this.empId)
          .map(response => response.json());
      
  
        }  
}