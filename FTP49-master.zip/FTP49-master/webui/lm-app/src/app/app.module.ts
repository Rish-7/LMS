import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpModule } from '@angular/http';
import { RouterModule,Routes } from '@angular/router';

import { AppComponent } from './app.component';
import { LoginFormComponent } from './login-form/login-form.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { EmployeeComponent } from './employee.component';
import { FormsModule } from '@angular/forms';
import { HistoryComponent } from './history/history.component';
import { HistoryService } from './history/history.service';
import { ApplyLeaveComponent } from './apply-leave/apply-leave.component';

const appRoutes:Routes =[
  {path:"", component:EmployeeComponent },
  {path:'login', component:LoginFormComponent },
  {path:'dashboard', component:DashboardComponent },
  {path:'history', component:HistoryComponent },
  {path:'apply', component:ApplyLeaveComponent }
];
@NgModule({
  declarations: [
    AppComponent,
    LoginFormComponent,
    DashboardComponent,
    EmployeeComponent,
    HistoryComponent,
    ApplyLeaveComponent
  ],
  imports: [
    BrowserModule,
    HttpModule,
    RouterModule.forRoot(appRoutes),
    FormsModule
  ],
  providers: [HistoryService],
  bootstrap: [AppComponent]
})
export class AppModule { }
