Creating Project Board:
    * select the projects tab in your project
*	[Click NEW PROJECT button]
*	Enter - Project Board Name << Test Project>>
*	Enter - Project Description<< Used for collating all the sprints >> 
*	Select - Project template "None"
*	Select[Click] - create project button

In your project in the project board
*	Select[Click] Add a column button
*	Add [Enter] Column Name as "To Do"
*	Select "To do " in Automation
*	Select all newly added issues and pull request here
*	select move all the reopened issues and pull request here
*	select[click] CREATE COLUMN button

* select Add a column 
* Add column name as "In Progress" 
* Select "In Progress" in Automation
* select create column button

* select Add a column 
* Add column name as "Done" 
* Select "Done in Automation
* select the button "Move all closed issues here"
* select "All merged pull request here"
* select create column button
Creating Mile Stone:
	* Select the issues tab in the project
	* select the Milestones tab in the issues board in the project
	* select New milestones button 
	* Enter <<Sprint with its number>>
	* Enter due date <<One-week time from the current date>>
	* Description about the sprint in the description column
	* Enter create milestone button

create Labels:
	* Select the label tab in the issues board in the project

creating label for "epic"
	* Select New Label button
	* Enter Name "epic"
	* Select Automation "epic"
	* Select Create Label	

creating label for "Task"
	* Select New Label button
	* Enter Name "Task"
	* Select Automation "Task"
	* Select Create Label	

creating label for "TO Do"	
	* Select New Label button
	* Enter Name " To Do "
	* Select Automation " To Do "
	* Select Create Label
	* Repeat same for creating other labels

creating label for "in progress"
	* Select New Label button
	* Enter Name "In progress"
	* Select Automation "In Progress"
	* Select Create Label	
	
creating label for "Done"
	* Select New Label button
	* Enter Name "Done"
	* Select Automation "Done"
	* Select Create Label	

Creating the Issue
	* Select the Issue tab in the top of the screen
	* select New Issue
	* Enter Name as Task1
	* Assign the task to a participant under Assignee drop down button
	* Select the label related to task ("To do"/"In progress", "Done")
    * Select the milestone with the sprint related to your task
    * Once summiting the Issue will generate the ticket number for you          ex#100
Ensure the visibility of the task in the project board in To Do column 

Note:
* Ensure that the task moved to "To Do " column in Project Board once after   creating the task/issue. 
* Move the task/issue to "In Progress" column after commensing your task in   "Visual Studio".  
* Move the task/issue to "Done" column of the project board after             completing the task/issue
* After moving all the task/issues in to "Done" column 
* Move the "epic" to " Done" column in the project board
