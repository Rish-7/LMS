package com.hexaware.ftp49.model;
/**
 *enum is used to store leave type.
 */
public enum LeaveType {
/**
 * Earned Leave.
 */
EL
/*PL
SL
*/
}

