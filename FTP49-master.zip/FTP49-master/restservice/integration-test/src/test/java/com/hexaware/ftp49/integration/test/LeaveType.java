package com.hexaware.ftp49.integration.test;
/**
 *enum is used to store leave type.
 */
public enum LeaveType {
/**
 * Earned Leave.
 */
EL
}

