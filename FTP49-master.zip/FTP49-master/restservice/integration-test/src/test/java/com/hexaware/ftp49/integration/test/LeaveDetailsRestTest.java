package com.hexaware.ftp49.integration.test;


import java.util.Arrays;
//import io.restassured.RestAssured;
//import static io.restassured.RestAssured.*;
import java.util.HashMap;
import java.util.Map;
//import org.testng.annotations.BeforeTest;
//import org.testng.annotations.Test;
import static org.hamcrest.Matchers.*;
import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
import javax.management.RuntimeErrorException;
import java.text.ParseException;
import java.net.URISyntaxException;
import java.text.SimpleDateFormat;
import org.junit.Test;
import static org.junit.Assert.*;

import com.jayway.restassured.http.ContentType;
import com.jayway.restassured.path.json.JsonPath;
import static com.jayway.restassured.RestAssured.given;

public class LeaveDetailsRestTest {

	@Test
	public final void testPOST() throws ParseException{
        given()
		.contentType(ContentType.JSON)
		.body(new HashMap<String,Object>() {{ 
        put("empId", "2000");
		put("leaveId", "0");
		put("leaveAppliedOn","2018-08-10");
		put("leaveDaysLeft", "3");
        put("leaveStartDate","2018-08-21");
        put("leaveEndDate", "2018-08-23");
        put("leaveType", "EL");
        put("leaveReason", "SICK");
        put("leaveStatus", "PENDING");
        put("leaveManagerComments", "NOT YET PROCESSED");
        }})
		.when()
		.post("http://localhost:8080/FTP49-0.0.1-SNAPSHOT/api/leavedetailsrest/2000/Updation")
		.then()
	    .statusCode(200).
		log().everything();
	}
}
   
